# Royal Blossoms Bot

Windows / VS Code setup (Python 3.11 or newer recommended):
1. Extract this folder and open it in VS Code (File > Open Folder).
2. In https://discord.com/developers/applications create an application named Royal Blossoms. In Bot, enable Message Content Intent and reset/copy the bot token. Never share the token.
3. In Installation configure Guild Install with bot and applications.commands scopes. Grant View Channels, Send Messages, Embed Links, Attach Files, Read Message History, Manage Channels, Manage Messages, and Manage Roles only if using role rewards. Install to your test server. Do not grant Administrator unnecessarily.
4. Discord Settings > Advanced > Developer Mode. Right click the server > Copy Server ID.
5. Open VS Code Terminal (PowerShell), run:
   py -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   Copy-Item .env.example .env
6. Open .env in VS Code and replace the placeholders with your bot token and server ID. Save.
7. Run .\.venv\Scripts\python.exe bot.py . Keep terminal open.

Create four event text channels, an announcement channel, a staff-only log channel, an event staff role and a ticket category. Copy their IDs using Developer Mode. Use /admin set in Discord, with key and value options:
- earning_channels: comma-separated text channel IDs (only these channels earn currency)
- event_channels: comma-separated IDs of up to four event channels
- general_channel: chat channel ID for drops
- log_channel: private staff channel ID for transcripts and audit messages
- announcement_channel: announcement channel ID
- staff_role: event staff role ID
- ticket_category: ticket category ID
- budget_cents: monthly reward budget in euro cents (5000 = EUR 50)

Use /admin config to see all settings; /admin set to update them. /admin shop-add creates items; stock -1 means unlimited, 0 disables an item. Test with cost_cents=0 before offering real prizes. Real prizes are delivered manually by eligible adult administrators; /admin fulfill records delivery or grants a configured safe role. No automatic payments.

Test /daily, /balance, /quests, /profile, /leaderboard, /support, /event create, /event reward, /event submissions, /event end, /shop, /buy, /redeem and /admin orders. Ticket buttons close/archive or delete/archive. Use /event clear only after the event ends, with confirm=True. It clears up to 500 non-pinned messages per call. Event rewards are one payment per member per event; calculate the total score first. Deadline extensions update the database, not old announcements. Refunds restore currency but stock must be adjusted manually. Monthly budget counts pending and completed orders from their purchase month. Quest resets use UTC.

SQLite creates royal.db automatically. Run only one bot process and use one server per database. Back up the database with the bot stopped. Do not commit .env or the database. Transcripts contain member messages and attachment URLs; restrict access, establish a retention policy and tell users how submissions are logged. Attachment URLs may expire. Keep your bot token private. To operate 24/7 deploy to a host with persistent disk storage. This source was syntax checked, not tested against a live Discord server. Test permissions and all features on a private server before launch.

## Railway deployment
Push these files to a private GitHub repository. Deploy that repository on Railway. Attach a persistent volume at `/data`, set `DB_PATH=/data/royal.db`, `DISCORD_TOKEN`, and `GUILD_ID` in service variables. Start command: `python bot.py`. Use one replica and disable serverless sleeping if available. Never commit .env or database files. Back up the volume regularly.
