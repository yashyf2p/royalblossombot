import os, sqlite3, time, random, io, datetime, asyncio, re
import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv
load_dotenv()
TOKEN=os.getenv('DISCORD_TOKEN'); GUILD_ID=int(os.getenv('GUILD_ID','0'))
db_path = os.getenv('DB_PATH', 'royal.db')
os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
DB=sqlite3.connect(db_path); DB.row_factory=sqlite3.Row
DB.executescript('''
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS members(id INTEGER PRIMARY KEY,balance INTEGER DEFAULT 0,xp INTEGER DEFAULT 0,last_msg INTEGER DEFAULT 0,last_daily INTEGER DEFAULT 0,last_text TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY,user INTEGER,amount INTEGER,reason TEXT,actor INTEGER,stamp INTEGER);
CREATE TABLE IF NOT EXISTS progress(user INTEGER,period TEXT,kind TEXT,n INTEGER DEFAULT 0,claimed INTEGER DEFAULT 0,PRIMARY KEY(user,period,kind));
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,channel INTEGER,title TEXT,details TEXT,reward INTEGER,deadline INTEGER,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS awards(event INTEGER,user INTEGER,amount INTEGER,PRIMARY KEY(event,user));
CREATE TABLE IF NOT EXISTS tickets(channel INTEGER PRIMARY KEY,user INTEGER,event INTEGER,kind TEXT,order_id INTEGER DEFAULT 0,closed INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS shop(id INTEGER PRIMARY KEY,name TEXT,price INTEGER,cost INTEGER,stock INTEGER,role INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,user INTEGER,item TEXT,price INTEGER,cost INTEGER,month TEXT,status TEXT DEFAULT 'pending',role INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS drops(id INTEGER PRIMARY KEY,channel INTEGER,amount INTEGER,expires INTEGER,winner INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS warnings(channel INTEGER PRIMARY KEY,stamp INTEGER);
'''); DB.commit()
DEFAULTS={'currency':'Royal Petals','message_rate':'2','message_xp':'5','cooldown':'60','daily_reward':'100','booster_percent':'125','daily_messages':'30','weekly_messages':'150','daily_quest_reward':'150','weekly_quest_reward':'600','daily_events':'1','weekly_events':'3','daily_event_reward':'100','weekly_event_reward':'400','quest_xp':'50','drop_min':'50','drop_max':'250','drop_chance':'2','budget_cents':'0','earning_channels':'','event_channels':'','general_channel':'0','log_channel':'0','staff_role':'0','ticket_category':'0','announcement_channel':'0','cleanup_days':'9','level_xp':'1000','level_reward':'100'}
def cfg(k):
 r=DB.execute('SELECT value FROM config WHERE key=?',(k,)).fetchone(); return r[0] if r else DEFAULTS[k]
def num(k): return int(cfg(k))
def ids(k): return {int(x) for x in cfg(k).split(',') if x.strip()}
def now(): return int(time.time())
def month(): return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m')
def periods():
 d=datetime.datetime.now(datetime.timezone.utc); return d.strftime('%Y-%m-%d'),d.strftime('%G-W%V')
def member(u):
 DB.execute('INSERT OR IGNORE INTO members(id) VALUES(?)',(u,)); return DB.execute('SELECT * FROM members WHERE id=?',(u,)).fetchone()
def change(u,a,reason,actor=0):
 m=member(u)
 if m['balance']+a<0: raise ValueError('Insufficient balance.')
 DB.execute('UPDATE members SET balance=balance+? WHERE id=?',(a,u)); DB.execute('INSERT INTO ledger(user,amount,reason,actor,stamp) VALUES(?,?,?,?,?)',(u,a,reason,actor,now()))
def xp(u,a):
 m=member(u); step=max(1,num('level_xp')); gained=(m['xp']+a)//step-m['xp']//step
 DB.execute('UPDATE members SET xp=xp+? WHERE id=?',(a,u))
 if gained: change(u,gained*num('level_reward'),'Level reward')
def progress(u,kind):
 for p in periods(): DB.execute('INSERT INTO progress(user,period,kind,n) VALUES(?,?,?,1) ON CONFLICT(user,period,kind) DO UPDATE SET n=n+1',(u,p,kind))
def embed(title,desc=''):
 return discord.Embed(title=title,description=desc,color=0xA76BD5).set_footer(text='Royal Blossoms • Community')
def money(a): return f'🌸 {a:,} {cfg("currency")}'
def staff(i): return i.user.guild_permissions.manage_guild or any(r.id==num('staff_role') for r in i.user.roles)
def admin(i): return i.user.guild_permissions.manage_guild
async def reply(i,msg,private=True):
 if i.response.is_done(): await i.followup.send(msg,ephemeral=private)
 else: await i.response.send_message(msg,ephemeral=private)
async def guard(i,administrator=False):
 if not (admin(i) if administrator else staff(i)): await reply(i,'You do not have permission.'); return False
 return True
intents=discord.Intents.default(); intents.message_content=True
class Bot(commands.Bot):
 async def setup_hook(self):
  self.add_view(TicketView()); self.add_view(EventView()); self.add_view(DropView()); self.add_view(ShopView()); self.add_view(QuestView())
  if GUILD_ID:
   g=discord.Object(id=GUILD_ID); self.tree.copy_global_to(guild=g); await self.tree.sync(guild=g)
  else: await self.tree.sync()
  maintenance.start()
bot=Bot(command_prefix=commands.when_mentioned,intents=intents)
@bot.tree.interaction_check
async def check_guild(i):
 if not i.guild or (GUILD_ID and i.guild.id!=GUILD_ID): await reply(i,'This bot is configured for one server.'); return False
 return True
@bot.event
async def on_ready(): print(f'Online as {bot.user}')
@bot.event
async def on_message(m):
 if m.author.bot or not m.guild or m.guild.id!=GUILD_ID or m.channel.id not in ids('earning_channels'): return
 normalized=' '.join(m.content.lower().split())
 if len(normalized)<4: return
 with DB:
  r=member(m.author.id)
  if now()-r['last_msg']<num('cooldown') or normalized==r['last_text']: return
  rate=num('message_rate'); rate=rate*num('booster_percent')//100 if m.author.premium_since else rate
  change(m.author.id,rate,'Chat activity'); xp(m.author.id,num('message_xp')); progress(m.author.id,'messages')
  DB.execute('UPDATE members SET last_msg=?,last_text=? WHERE id=?',(now(),normalized,m.author.id))
@bot.tree.command(description='View your Royal Petals balance')
async def balance(i:discord.Interaction):
 with DB: r=member(i.user.id)
 await i.response.send_message(embed=embed('Royal Balance',money(r['balance'])))
@bot.tree.command(description='Claim your reward every 24 hours')
async def daily(i:discord.Interaction):
 with DB:
  r=member(i.user.id); remaining=86400-(now()-r['last_daily'])
  if remaining<=0:
   change(i.user.id,num('daily_reward'),'Daily reward'); DB.execute('UPDATE members SET last_daily=? WHERE id=?',(now(),i.user.id))
 await reply(i,f'Try again <t:{now()+remaining}:R>.' if remaining>0 else f'Claimed {money(num("daily_reward"))}!')
async def profile_show(i,user):
 with DB: r=member(user.id)
 step=num('level_xp'); n=r['xp']%step; bar='🟪'*int(n/step*10)+'⬜'*(10-int(n/step*10))
 e=embed(f'{user.display_name} • Royal Profile',f'{money(r["balance"])}\nLevel {r["xp"]//step+1} • {r["xp"]:,} XP\n{bar}\n{n}/{step} XP'); e.set_thumbnail(url=user.display_avatar.url)
 await i.response.send_message(embed=e)
@bot.tree.command(description='View a member profile')
async def profile(i:discord.Interaction,user:discord.Member=None): await profile_show(i,user or i.user)
@bot.tree.command(description='View your level and XP')
async def level(i:discord.Interaction): await profile_show(i,i.user)
@bot.tree.command(description='View server rankings')
@app_commands.choices(kind=[app_commands.Choice(name='Currency',value='balance'),app_commands.Choice(name='XP',value='xp')])
async def leaderboard(i:discord.Interaction,kind:app_commands.Choice[str]):
 col=kind.value if kind.value in ('balance','xp') else 'balance'; rows=DB.execute(f'SELECT id,{col} FROM members ORDER BY {col} DESC LIMIT 10').fetchall()
 await i.response.send_message(embed=embed('Royal Rankings','\n'.join(f'**{j}.** <@{r[0]}> — {r[1]:,}' for j,r in enumerate(rows,1)) or 'No rankings yet.'))
@bot.tree.command(description='View recent currency movements')
async def transactions(i:discord.Interaction):
 rows=DB.execute('SELECT * FROM ledger WHERE user=? ORDER BY id DESC LIMIT 10',(i.user.id,)).fetchall(); await reply(i,'\n'.join(f'{r["amount"]:+,} • {r["reason"]}' for r in rows) or 'No transactions.')
def quest_rows(u):
 for prefix,p in zip(('daily','weekly'),periods()):
  for kind in ('messages','events'):
   target=num(f'{prefix}_{kind}'); reward=num(f'{prefix}_quest_reward' if kind=='messages' else f'{prefix}_event_reward')
   r=DB.execute('SELECT n,claimed FROM progress WHERE user=? AND period=? AND kind=?',(u,p,kind)).fetchone(); yield prefix,p,kind,target,reward,(r[0] if r else 0),(r[1] if r else 0)
class QuestView(discord.ui.View):
 def __init__(self): super().__init__(timeout=None)
 @discord.ui.button(label='Claim completed missions',style=discord.ButtonStyle.success,custom_id='rb:quests')
 async def claim(self,i,b):
  total=0; count=0
  with DB:
   for _,p,k,t,r,n,c in quest_rows(i.user.id):
    if n>=t and not c:
     DB.execute('UPDATE progress SET claimed=1 WHERE user=? AND period=? AND kind=?',(i.user.id,p,k)); change(i.user.id,r,'Quest reward'); xp(i.user.id,num('quest_xp')); total+=r; count+=1
  await reply(i,f'Claimed {count} missions: {money(total)}.')
@bot.tree.command(description='View daily and weekly missions')
async def quests(i:discord.Interaction):
 e=embed('Royal Missions','Daily and weekly resets use UTC.')
 for prefix,p,k,t,r,n,c in quest_rows(i.user.id):
  filled=min(10,int(n/max(1,t)*10)); e.add_field(name=f'{prefix.title()} {k}',value=f'{"🟪"*filled}{"⬜"*(10-filled)}\n{n}/{t} • {money(r)}'+(' • Claimed' if c else ''),inline=False)
 await i.response.send_message(embed=e,view=QuestView(),ephemeral=True)
@bot.tree.command(description='View server booster benefits')
async def booster_perks(i:discord.Interaction): await reply(i,f'Boosters receive {num("booster_percent")}% of normal message earnings.')
@bot.tree.command(description='Learn how to earn rewards')
async def economy_help(i:discord.Interaction): await reply(i,'Earn Petals by eligible chat activity, /daily, /quests and events. Spend them with /shop. Spam does not count. Use /profile and /transactions to track progress.')
async def log(g,title,description):
 c=g.get_channel(num('log_channel'))
 if c: await c.send(embed=embed(title,description),allowed_mentions=discord.AllowedMentions.none())
async def open_ticket(i,kind,event=0,order=0):
 if not i.guild or i.guild.id!=GUILD_ID: return await reply(i,'Wrong server.')
 existing=DB.execute('SELECT channel FROM tickets WHERE user=? AND kind=? AND event=? AND order_id=? AND closed=0',(i.user.id,kind,event,order)).fetchone()
 if existing and i.guild.get_channel(existing[0]): return await reply(i,f'Your ticket: <#{existing[0]}>')
 await i.response.defer(ephemeral=True)
 g=i.guild; role=g.get_role(num('staff_role')); category=g.get_channel(num('ticket_category'))
 overwrites={g.default_role:discord.PermissionOverwrite(view_channel=False),i.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True),g.me:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True,manage_channels=True)}
 if role: overwrites[role]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
 c=await g.create_text_channel(f'{kind}-{i.user.id}',category=category if isinstance(category,discord.CategoryChannel) else None,overwrites=overwrites)
 with DB: DB.execute('INSERT INTO tickets(channel,user,event,kind,order_id) VALUES(?,?,?,?,?)',(c.id,i.user.id,event,kind,order))
 await c.send(content=i.user.mention,embed=embed('Royal Support',f'Type: {kind}\nEvent ID: {event or "N/A"}\nOrder ID: {order or "N/A"}\nPost your answers, proof or request here. Staff will review it.'),view=TicketView())
 await reply(i,f'Ticket created: {c.mention}')
async def close_ticket(i,delete=False):
 if not await guard(i): return
 r=DB.execute('SELECT * FROM tickets WHERE channel=?',(i.channel_id,)).fetchone()
 if not r: return await reply(i,'Not a ticket.')
 await i.response.defer(ephemeral=True)
 c=i.guild.get_channel(num('log_channel'))
 if not c: return await reply(i,'Configure log_channel before closing tickets.')
 lines=[f'Ticket {i.channel_id} | user {r["user"]} | event {r["event"]} | order {r["order_id"]} | closed by {i.user.id}']
 async for m in i.channel.history(limit=None,oldest_first=True):
  lines.append(f'{m.created_at.isoformat()} | {m.author} ({m.author.id}): {m.content} '+ ' '.join(a.url for a in m.attachments))
 data='\n'.join(lines).encode('utf-8'); await c.send(file=discord.File(io.BytesIO(data),filename=f'ticket-{i.channel_id}.txt'),allowed_mentions=discord.AllowedMentions.none())
 with DB: DB.execute('UPDATE tickets SET closed=1 WHERE channel=?',(i.channel_id,))
 if delete: await reply(i,'Transcript saved. Deleting ticket.'); await i.channel.delete(reason=f'Ticket closed by {i.user}')
 else:
  u=i.guild.get_member(r['user'])
  if u: await i.channel.set_permissions(u,view_channel=False,send_messages=False)
  await reply(i,'Ticket closed and transcript saved.')
class TicketView(discord.ui.View):
 def __init__(self): super().__init__(timeout=None)
 @discord.ui.button(label='Close ticket',style=discord.ButtonStyle.secondary,custom_id='rb:close')
 async def close(self,i,b): await close_ticket(i)
 @discord.ui.button(label='Delete & archive',style=discord.ButtonStyle.danger,custom_id='rb:delete')
 async def delete(self,i,b): await close_ticket(i,True)
class EventView(discord.ui.View):
 def __init__(self): super().__init__(timeout=None)
 @discord.ui.button(label='Submit event answers',style=discord.ButtonStyle.primary,custom_id='rb:submit')
 async def submit(self,i,b):
  match=re.search(r'Event ID: (\d+)',i.message.embeds[0].footer.text or '') if i.message.embeds else None
  r=DB.execute('SELECT * FROM events WHERE id=? AND active=1 AND deadline>?',(int(match[1]) if match else 0,now())).fetchone()
  if not r: return await reply(i,'This event is closed.')
  await open_ticket(i,'event',r['id'])
@bot.tree.command(description='Open a private support ticket')
async def support(i:discord.Interaction): await open_ticket(i,'support')
event=app_commands.Group(name='event',description='Event management'); bot.tree.add_command(event)
@event.command(name='create',description='Create and announce an event')
async def event_create(i:discord.Interaction,channel:discord.TextChannel,title:str,details:str,reward:app_commands.Range[int,0,1000000],hours:app_commands.Range[int,1,720]):
 if not await guard(i): return
 if channel.id not in ids('event_channels'): return await reply(i,'Channel is not configured for events.')
 if DB.execute('SELECT 1 FROM events WHERE channel=? AND active=1',(channel.id,)).fetchone(): return await reply(i,'End the existing event first.')
 with DB: eid=DB.execute('INSERT INTO events(channel,title,details,reward,deadline) VALUES(?,?,?,?,?)',(channel.id,title,details,reward,now()+hours*3600)).lastrowid
 await i.response.defer(ephemeral=True)
 e=embed(title,f'{details}\n\nReward: {money(reward)}\nDeadline: <t:{now()+hours*3600}:F>\nEvent channel: {channel.mention}').set_footer(text=f'Royal Blossoms • Event ID: {eid}')
 await channel.send(embed=e,view=EventView(),allowed_mentions=discord.AllowedMentions.none())
 a=i.guild.get_channel(num('announcement_channel'))
 if a and a!=channel: await a.send(embed=e,view=EventView(),allowed_mentions=discord.AllowedMentions.none())
 await reply(i,f'Event #{eid} created.')
def award(eid,u,a,actor):
 if not DB.execute('SELECT 1 FROM events WHERE id=?',(eid,)).fetchone(): raise ValueError('Event not found.')
 if DB.execute('SELECT 1 FROM awards WHERE event=? AND user=?',(eid,u)).fetchone(): raise ValueError('Already rewarded for this event.')
 DB.execute('INSERT INTO awards VALUES(?,?,?)',(eid,u,a)); change(u,a,f'Event #{eid}',actor); progress(u,'events')
@event.command(name='reward',description='Award a member once per event')
async def event_reward(i:discord.Interaction,event_id:int,user:discord.Member,amount:app_commands.Range[int,0,1000000]):
 if not await guard(i): return
 try:
  with DB: award(event_id,user.id,amount,i.user.id)
 except ValueError as e: return await reply(i,str(e))
 await reply(i,f'Awarded {money(amount)} to {user.mention}.'); await log(i.guild,'Event reward',f'Event #{event_id} • {user.mention} • {money(amount)} • {i.user.mention}')
@event.command(name='bulk-reward',description='Award multiple members by comma-separated Discord IDs')
async def bulk_reward(i:discord.Interaction,event_id:int,user_ids:str,amount:app_commands.Range[int,0,1000000]):
 if not await guard(i): return
 try: users={int(x.strip()) for x in user_ids.split(',')}; assert 0<len(users)<=100
 except (ValueError,AssertionError): return await reply(i,'Provide 1–100 comma-separated member IDs.')
 await i.response.defer(ephemeral=True); done=0; skipped=[]
 for u in users:
  try:
   await i.guild.fetch_member(u)
   with DB: award(event_id,u,amount,i.user.id)
   done+=1
  except (ValueError,discord.NotFound): skipped.append(str(u))
 await reply(i,f'Rewarded {done}; skipped {len(skipped)}: '+', '.join(skipped)[:1500]); await log(i.guild,'Bulk reward',f'Event #{event_id}, {done} members, {money(amount)} each, actor {i.user.id}')
@event.command(name='end',description='End an event without deleting its records')
async def event_end(i:discord.Interaction,event_id:int):
 if not await guard(i): return
 with DB: DB.execute('UPDATE events SET active=0 WHERE id=?',(event_id,))
 await reply(i,f'Event #{event_id} ended.')
@event.command(name='extend',description='Extend event deadline')
async def event_extend(i:discord.Interaction,event_id:int,hours:app_commands.Range[int,1,720]):
 if not await guard(i): return
 with DB: DB.execute('UPDATE events SET deadline=MAX(deadline,?)+? WHERE id=? AND active=1',(now(),hours*3600,event_id))
 await reply(i,'Deadline updated in database. Existing announcements need updating manually.')
@event.command(name='history',description='List recent events')
async def event_history(i:discord.Interaction):
 rows=DB.execute('SELECT * FROM events ORDER BY id DESC LIMIT 15').fetchall(); await reply(i,'\n'.join(f'#{r["id"]} {r["title"]} • {"Active" if r["active"] else "Ended"}' for r in rows) or 'No events.')
@event.command(name='submissions',description='List event submission tickets and awards')
async def submissions(i:discord.Interaction,event_id:int):
 if not await guard(i): return
 rows=DB.execute('SELECT t.*,a.amount FROM tickets t LEFT JOIN awards a ON a.event=t.event AND a.user=t.user WHERE t.event=? LIMIT 30',(event_id,)).fetchall(); await reply(i,'\n'.join(f'<@{r["user"]}> • <#{r["channel"]}> • {r["amount"] if r["amount"] is not None else "Unpaid"}' for r in rows) or 'No submissions.')
@event.command(name='clear',description='Clear ended event channel; requires confirmation')
async def clear(i:discord.Interaction,channel:discord.TextChannel,confirm:bool=False):
 if not await guard(i): return
 if not confirm or channel.id not in ids('event_channels') or DB.execute('SELECT 1 FROM events WHERE channel=? AND active=1',(channel.id,)).fetchone(): return await reply(i,'Use a configured event channel, end its event, and set confirm=True.')
 await i.response.defer(ephemeral=True); deleted=await channel.purge(limit=500,check=lambda m: not m.pinned,reason=f'Event cleanup by {i.user}'); await reply(i,f'Cleared {len(deleted)} non-pinned messages. Repeat if needed.'); await log(i.guild,'Event cleanup',f'{channel.mention}: {len(deleted)} messages by {i.user.mention}')
def available():
 used=DB.execute("SELECT COALESCE(SUM(cost),0) FROM orders WHERE month=? AND status IN ('pending','completed')",(month(),)).fetchone()[0]; return num('budget_cents')-used
async def purchase(i,item_id):
 try:
  with DB:
   r=DB.execute('SELECT * FROM shop WHERE id=?',(item_id,)).fetchone()
   if not r or r['stock']==0: raise ValueError('Item unavailable.')
   if r['cost']>0 and r['cost']>available(): raise ValueError('Monthly reward budget exhausted.')
   change(i.user.id,-r['price'],f'Shop: {r["name"]}'); oid=DB.execute('INSERT INTO orders(user,item,price,cost,month,role) VALUES(?,?,?,?,?,?)',(i.user.id,r['name'],r['price'],r['cost'],month(),r['role'])).lastrowid
   DB.execute('UPDATE shop SET stock=CASE WHEN stock>0 THEN stock-1 ELSE stock END WHERE id=?',(item_id,))
 except ValueError as e: return await reply(i,str(e))
 await reply(i,f'Purchased {r["name"]}! Order #{oid}. Use /redeem {oid} to claim.')
class ShopView(discord.ui.View):
 def __init__(self): super().__init__(timeout=None)
 @discord.ui.button(label='Purchase instructions',style=discord.ButtonStyle.primary,custom_id='rb:shop')
 async def buy(self,i,b): await reply(i,'Use /buy with the item ID shown in the marketplace, then /redeem with your order ID.')
@bot.tree.command(description='Browse the Royal Marketplace')
async def shop(i:discord.Interaction):
 rows=DB.execute('SELECT * FROM shop ORDER BY id LIMIT 25').fetchall(); e=embed('Royal Marketplace','Use /buy with an item ID.');
 for r in rows: e.add_field(name=f'#{r["id"]} • {r["name"]}',value=f'{money(r["price"])} • Stock: {r["stock"] if r["stock"]>=0 else "Unlimited"}',inline=False)
 await i.response.send_message(embed=e,view=ShopView())
@bot.tree.command(description='Purchase an item with Petals')
async def buy(i:discord.Interaction,item_id:int): await purchase(i,item_id)
@bot.tree.command(description='Open a ticket to claim a purchased reward')
async def redeem(i:discord.Interaction,order_id:int):
 if not DB.execute("SELECT 1 FROM orders WHERE id=? AND user=? AND status='pending'",(order_id,i.user.id)).fetchone(): return await reply(i,'No matching pending order.')
 await open_ticket(i,'redemption',order=order_id)
@bot.tree.command(description='View your recent reward orders')
async def redemption_queue(i:discord.Interaction):
 rows=DB.execute('SELECT * FROM orders WHERE user=? ORDER BY id DESC LIMIT 15',(i.user.id,)).fetchall(); await reply(i,'\n'.join(f'#{r["id"]} {r["item"]} — {r["status"]}' for r in rows) or 'No orders.')
@bot.tree.command(description='Check remaining reward budget')
async def check_budget(i:discord.Interaction): await reply(i,f'Available this month: €{available()/100:.2f}')
class DropView(discord.ui.View):
 def __init__(self): super().__init__(timeout=None)
 @discord.ui.button(label='Claim Royal Drop',style=discord.ButtonStyle.success,custom_id='rb:drop')
 async def claim(self,i,b):
  if not i.guild or i.guild.id!=GUILD_ID: return await reply(i,'Wrong server.')
  with DB:
   r=DB.execute('SELECT * FROM drops WHERE id=?',(i.message.id,)).fetchone()
   if not r or r['winner'] or r['expires']<now(): return await reply(i,'Drop already claimed or expired.')
   DB.execute('UPDATE drops SET winner=? WHERE id=?',(i.user.id,i.message.id)); change(i.user.id,r['amount'],'Royal Drop')
  await i.response.edit_message(embed=embed('Royal Drop claimed',f'{i.user.mention} received {money(r["amount"])}!'),view=None)
async def send_drop(g):
 c=g.get_channel(num('general_channel'))
 if not c: return False
 a=random.randint(num('drop_min'),num('drop_max')); m=await c.send(embed=embed('🌸 A Royal Drop appeared!',f'First to claim receives {money(a)}. Expires in 5 minutes.'),view=DropView())
 with DB: DB.execute('INSERT INTO drops(id,channel,amount,expires) VALUES(?,?,?,?)',(m.id,c.id,a,now()+300))
 return True
settings=app_commands.Group(name='admin',description='Royal Blossoms administration'); bot.tree.add_command(settings)
@settings.command(name='config',description='View all current settings')
async def config(i:discord.Interaction):
 if not await guard(i,True): return
 await reply(i,'\n'.join(f'`{k}` = {cfg(k) or "not set"}' for k in DEFAULTS))
@settings.command(name='set',description='Update a setting without editing source code')
async def config_set(i:discord.Interaction,key:str,value:str):
 if not await guard(i,True): return
 if key not in DEFAULTS: return await reply(i,'Unknown setting. See /admin config.')
 try:
  if key in ('earning_channels','event_channels'):
   parsed=[int(x.strip()) for x in value.split(',') if x.strip()]; assert all(isinstance(i.guild.get_channel(x),discord.TextChannel) for x in parsed); assert key!='event_channels' or len(set(parsed))<=4
   value=','.join(map(str,parsed))
  elif key=='currency': assert 1<=len(value)<=40
  else:
   n=int(value); assert 0<=n<=10**18
   if key in ('level_xp','daily_messages','weekly_messages','daily_events','weekly_events','cooldown','cleanup_days'): assert n>=1
   if key=='drop_chance': assert n<=100
   if key=='drop_min': assert n<=num('drop_max')
   if key=='drop_max': assert n>=num('drop_min')
   if key=='staff_role' and n: assert i.guild.get_role(n) and n!=i.guild.id
   if key in ('general_channel','log_channel','announcement_channel') and n: assert isinstance(i.guild.get_channel(n),discord.TextChannel)
   if key=='ticket_category' and n: assert isinstance(i.guild.get_channel(n),discord.CategoryChannel)
   value=str(n)
 except (ValueError,AssertionError): return await reply(i,'Invalid setting value.')
 with DB: DB.execute('INSERT INTO config VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value))
 await reply(i,f'{key} updated.'); await log(i.guild,'Configuration change',f'{key} = {value} • {i.user.mention}')
@settings.command(name='balance',description='Add, remove or set member currency')
@app_commands.choices(mode=[app_commands.Choice(name=x,value=x) for x in ('add','remove','set')])
async def admin_balance(i:discord.Interaction,user:discord.Member,mode:app_commands.Choice[str],amount:app_commands.Range[int,0,100000000],reason:str):
 if not await guard(i,True): return
 try:
  with DB:
   r=member(user.id); a=amount if mode.value=='add' else -amount if mode.value=='remove' else amount-r['balance']; change(user.id,a,reason,i.user.id)
 except ValueError as e: return await reply(i,str(e))
 await reply(i,f'Balance updated by {a:+,}.'); await log(i.guild,'Balance adjustment',f'{user.mention}: {a:+,} • {reason} • {i.user.mention}')
@settings.command(name='shop-add',description='Create a shop item (real cost in euro cents; -1 stock means unlimited)')
async def shop_add(i:discord.Interaction,name:str,price:app_commands.Range[int,1,100000000],cost_cents:app_commands.Range[int,0,10000000],stock:app_commands.Range[int,-1,100000],role:discord.Role=None):
 if not await guard(i,True): return
 if role and (role.managed or role>=i.guild.me.top_role or role.permissions.administrator or role.permissions.manage_guild or role.permissions.manage_roles): return await reply(i,'Choose a safe reward role below the bot role.')
 with DB: oid=DB.execute('INSERT INTO shop(name,price,cost,stock,role) VALUES(?,?,?,?,?)',(name[:100],price,cost_cents,stock,role.id if role else 0)).lastrowid
 await reply(i,f'Item #{oid} added.')
@settings.command(name='shop-edit',description='Update item pricing and stock')
async def shop_edit(i:discord.Interaction,item_id:int,price:app_commands.Range[int,1,100000000],cost_cents:app_commands.Range[int,0,10000000],stock:app_commands.Range[int,-1,100000]):
 if not await guard(i,True): return
 with DB: DB.execute('UPDATE shop SET price=?,cost=?,stock=? WHERE id=?',(price,cost_cents,stock,item_id))
 await reply(i,'Item updated if it exists. Set stock to zero to disable.')
@settings.command(name='orders',description='List pending redemptions')
async def orders(i:discord.Interaction):
 if not await guard(i,True): return
 rows=DB.execute("SELECT * FROM orders WHERE status='pending' ORDER BY id LIMIT 20").fetchall(); await reply(i,'\n'.join(f'#{r["id"]} <@{r["user"]}> {r["item"]} • €{r["cost"]/100:.2f}' for r in rows) or 'No pending orders.')
@settings.command(name='fulfill',description='Mark a delivered prize complete or grant its configured role')
async def fulfill(i:discord.Interaction,order_id:int):
 if not await guard(i,True): return
 r=DB.execute("SELECT * FROM orders WHERE id=? AND status='pending'",(order_id,)).fetchone()
 if not r: return await reply(i,'No pending order.')
 await i.response.defer(ephemeral=True)
 if r['role']:
  role=i.guild.get_role(r['role']); u=await i.guild.fetch_member(r['user'])
  if not role or role>=i.guild.me.top_role or role.permissions.administrator or role.permissions.manage_guild or role.permissions.manage_roles: return await reply(i,'Role no longer safe or available.')
  await u.add_roles(role,reason=f'Royal order #{order_id}')
 with DB: DB.execute("UPDATE orders SET status='completed' WHERE id=? AND status='pending'",(order_id,))
 await reply(i,'Order marked completed.'); await log(i.guild,'Order fulfilled',f'Order #{order_id} by {i.user.mention}')
@settings.command(name='refund',description='Cancel pending order and restore currency')
async def refund(i:discord.Interaction,order_id:int):
 if not await guard(i,True): return
 with DB:
  r=DB.execute("SELECT * FROM orders WHERE id=? AND status='pending'",(order_id,)).fetchone()
  if r: change(r['user'],r['price'],f'Refund #{order_id}',i.user.id); DB.execute("UPDATE orders SET status='refunded' WHERE id=?",(order_id,))
 await reply(i,'Refunded. Adjust shop stock manually if necessary.' if r else 'No pending order.')
@settings.command(name='drop',description='Launch a Royal Drop in general chat')
async def drop(i:discord.Interaction):
 if not await guard(i,True): return
 await i.response.defer(ephemeral=True); await reply(i,'Drop launched.' if await send_drop(i.guild) else 'Configure general_channel first.')
@tasks.loop(minutes=30)
async def maintenance():
 g=bot.get_guild(GUILD_ID)
 if not g: return
 with DB: DB.execute('UPDATE events SET active=0 WHERE deadline<=?',(now(),))
 if random.randrange(100)<num('drop_chance'):
  try: await send_drop(g)
  except discord.HTTPException as e: print('Drop failed',e)
 for cid in ids('event_channels'):
  c=g.get_channel(cid)
  if not c: continue
  try:
   async for m in c.history(limit=1,oldest_first=True):
    if now()-int(m.created_at.timestamp())>=num('cleanup_days')*86400:
     r=DB.execute('SELECT stamp FROM warnings WHERE channel=?',(cid,)).fetchone()
     if not r or now()-r[0]>86400:
      await log(g,'Cleanup warning',f'{c.mention} contains old messages. End any active event before clearing.');
      with DB: DB.execute('INSERT OR REPLACE INTO warnings VALUES(?,?)',(cid,now()))
  except discord.HTTPException as e: print('Cleanup warning failed',e)
@maintenance.before_loop
async def before_maintenance(): await bot.wait_until_ready()
@bot.tree.error
async def command_error(i,error):
 print(repr(error)); await reply(i,'Command failed. Check bot permissions and console logs.')
if __name__=='__main__':
 if not TOKEN or not GUILD_ID: raise SystemExit('Set DISCORD_TOKEN and GUILD_ID in .env first.')
 bot.run(TOKEN)
